	Free Microsoft C Runtime and import library definitions

	Maintained by MinGW Developers
	Send bug reports and questions to MinGW-users@lists.sourceforge.net
	URL: http://www.mingw.org

A historical readme.txt exists and is distributed for your edification.  The 
references within may or may not be correct.  Please do not rely on them.  See
http://www.mingw.org for a list of valid references.

